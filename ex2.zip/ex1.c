#include<stdio.h>
	int main(){
		char fullname[50];
		printf("nhap ten cua ban: ");
		gets(fullname);
		printf("xin chao, ten cua ban la: %s",fullname);
		
		return 0;
	}
